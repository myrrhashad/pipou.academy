import { start } from 'rails-ujs';
import 'font-awesome/css/font-awesome.css';

require.context('../images/', true);

start();
