require('../styles/mailer.scss');
